package com.example.bean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeanApplicationTests {

	@Test
	void contextLoads() {
	}

}
