package com.example.my.module.user.controller;

public class UserController {
    
}
